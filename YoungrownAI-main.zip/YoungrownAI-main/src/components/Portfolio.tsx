import { Play } from 'lucide-react';

const Portfolio = () => {
  const projects = [
    {
      title: 'E-Learning Course Animation',
      category: 'E-Learning',
      gradient: 'from-blue-400 to-cyan-400'
    },
    {
      title: 'Educational Science Video',
      category: 'Educational',
      gradient: 'from-cyan-400 to-teal-400'
    },
    {
      title: 'Product Demo Animation',
      category: 'Product Demo',
      gradient: 'from-teal-400 to-green-400'
    },
    {
      title: 'Corporate Brand Story',
      category: '2D Animation',
      gradient: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Motion Graphics Reel',
      category: 'Motion Graphics',
      gradient: 'from-cyan-500 to-blue-500'
    },
    {
      title: 'Training Module Video',
      category: 'E-Learning',
      gradient: 'from-blue-400 to-cyan-500'
    }
  ];

  return (
    <section id="portfolio" className="py-20 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="text-blue-600">Portfolio</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover our diverse range of animation projects
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl aspect-video bg-gradient-to-br cursor-pointer hover:shadow-2xl transition-all duration-300"
              style={{
                backgroundImage: `linear-gradient(to bottom right, var(--tw-gradient-stops))`
              }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-90 group-hover:opacity-100 transition-opacity duration-300`}></div>

              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-white">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Play className="w-8 h-8 fill-white" />
                </div>
                <h3 className="text-2xl font-bold mb-2 text-center">{project.title}</h3>
                <span className="text-sm bg-white/20 backdrop-blur-sm px-4 py-1 rounded-full">
                  {project.category}
                </span>
              </div>

              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300"></div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 text-lg">
            Ready to see more? Contact us to view our complete portfolio
          </p>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
