import { Users, Award, Target } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            About <span className="text-blue-600">younGrownAI</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We are a professional animation studio dedicated to bringing your ideas to life through stunning visual storytelling
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 hover:shadow-xl transition-shadow duration-300">
            <div className="w-14 h-14 bg-blue-600 rounded-xl flex items-center justify-center mb-6">
              <Users className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Expert Team</h3>
            <p className="text-gray-600 leading-relaxed">
              20+ skilled animation professionals working together to deliver exceptional results
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 hover:shadow-xl transition-shadow duration-300">
            <div className="w-14 h-14 bg-blue-600 rounded-xl flex items-center justify-center mb-6">
              <Award className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Quality Focused</h3>
            <p className="text-gray-600 leading-relaxed">
              Committed to delivering high-quality animation solutions that exceed expectations
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 hover:shadow-xl transition-shadow duration-300">
            <div className="w-14 h-14 bg-blue-600 rounded-xl flex items-center justify-center mb-6">
              <Target className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Any Style</h3>
            <p className="text-gray-600 leading-relaxed">
              Expertise in diverse animation styles, specializing in 2D animation and e-learning content
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-cyan-500 rounded-3xl p-12 text-center text-white">
          <h3 className="text-3xl font-bold mb-4">Our Mission</h3>
          <p className="text-xl leading-relaxed max-w-4xl mx-auto opacity-95">
            At younGrownAI, we transform ideas into captivating animated experiences. Our team of 20+ animation experts combines creativity, technical excellence, and unwavering commitment to quality to deliver animation solutions that truly make an impact.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
