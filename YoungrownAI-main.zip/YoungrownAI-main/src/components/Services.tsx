import { Layers, GraduationCap, BookOpen, Zap, Video } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Layers,
      title: '2D Animation',
      description: 'Beautiful, engaging 2D animations that bring your stories and characters to life with fluid motion and vibrant visuals'
    },
    {
      icon: GraduationCap,
      title: 'E-Learning Videos',
      description: 'Interactive and educational content designed to enhance learning experiences and make complex topics easy to understand'
    },
    {
      icon: BookOpen,
      title: 'Educational Animations',
      description: 'Informative animations that simplify complex concepts and make learning engaging for all age groups'
    },
    {
      icon: Zap,
      title: 'Motion Graphics',
      description: 'Dynamic motion graphics that add visual interest and professional polish to your brand and marketing materials'
    },
    {
      icon: Video,
      title: 'Product Demo Videos',
      description: 'Clear, compelling product demonstrations that showcase features and benefits in an engaging animated format'
    }
  ];

  return (
    <section id="services" className="py-20 px-6 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="text-blue-600">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive animation solutions tailored to your needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <service.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
