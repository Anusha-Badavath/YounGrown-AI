import { FileText, Pencil, Video, MessageCircle, CheckCircle } from 'lucide-react';

const Process = () => {
  const steps = [
    {
      icon: FileText,
      title: 'Requirement',
      description: 'We understand your vision, goals, and specific animation needs'
    },
    {
      icon: Pencil,
      title: 'Storyboard',
      description: 'Visual planning and scene composition to map out your animation'
    },
    {
      icon: Video,
      title: 'Animation',
      description: 'Our expert team brings your story to life with stunning visuals'
    },
    {
      icon: MessageCircle,
      title: 'Feedback',
      description: 'We refine and perfect based on your valuable input'
    },
    {
      icon: CheckCircle,
      title: 'Final Delivery',
      description: 'Polished, high-quality animation delivered on time'
    }
  ];

  return (
    <section id="process" className="py-20 px-6 bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our <span className="text-blue-600">Process</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A streamlined workflow designed for transparency and excellence
          </p>
        </div>

        <div className="relative">
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-blue-200 via-cyan-200 to-blue-200 transform -translate-y-1/2"></div>

          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-8 relative">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-full flex items-center justify-center mb-6 relative z-10">
                      <step.icon className="w-8 h-8 text-white" />
                    </div>
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold mb-4 text-sm">
                      {index + 1}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-cyan-500 rounded-2xl p-8 text-white inline-block">
            <p className="text-lg font-medium">
              Simple, transparent, and efficient - that's how we work
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Process;
