import { ArrowRight, Sparkles } from 'lucide-react';

const CTA = () => {
  return (
    <section className="py-20 px-6 bg-gradient-to-br from-blue-600 via-cyan-500 to-blue-600">
      <div className="max-w-5xl mx-auto text-center">
        <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full mb-6">
          <Sparkles className="w-4 h-4" />
          <span className="text-sm font-medium">Ready to Start?</span>
        </div>

        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
          Let's Bring Your Ideas to Life
          <br />
          <span className="text-cyan-200">with Animation</span>
        </h2>

        <p className="text-xl text-white/90 mb-10 leading-relaxed max-w-3xl mx-auto">
          Partner with our team of 20+ animation experts to create stunning visuals that captivate your audience
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="mailto:youngrownai@gmail.com"
            className="px-8 py-4 bg-white text-blue-600 rounded-full font-semibold hover:bg-gray-100 hover:shadow-xl hover:scale-105 transition-all duration-200 flex items-center space-x-2"
          >
            <span>Get Started Today</span>
            <ArrowRight className="w-5 h-5" />
          </a>
          <a
            href="tel:7569751097"
            className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white rounded-full font-semibold border-2 border-white hover:bg-white/20 transition-all duration-200"
          >
            Call Us: 7569751097
          </a>
        </div>
      </div>
    </section>
  );
};

export default CTA;
